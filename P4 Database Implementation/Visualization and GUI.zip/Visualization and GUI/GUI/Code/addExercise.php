<?php
require 'includes/snippet.php';
require 'includes/db-inc.php';
include "includes/header.php";

if (isset($_POST['submit'])) {
    $Exercise_Id = sanitize(trim($_POST['Exercise_ID']));
    $Exercise_Name = sanitize(trim($_POST['Exercise_Name']));
    $Exercise_Type = sanitize(trim($_POST['Exercise_Type']));
    $Exercise_Timeslot = sanitize(trim($_POST['Exercise_Timeslot']));
    $Exercise_Number_Attending = sanitize(trim($_POST['Exercise_Number_Attending']));

    $sql = "INSERT INTO Exercise (Exercise_ID, Exercise_Name, Exercise_Type, Exercise_Timeslot, Exercise_Number_Attending)
            VALUES('$Exercise_Id', '$Exercise_Name', '$Exercise_Type', '$Exercise_Timeslot', '$Exercise_Number_Attending')";
    $query = mysqli_query($conn, $sql);

    if ($query) {
        echo "<script>alert('New Exercise has been added');location.href ='exercises_table.php';</script>";
    } else {
        echo "<script>alert('Exercise not added');</script>";
    }
}
?>
 <!DOCTYPE html>
<html>
<head>
    
    <style>
        body {
            background: url('BG.jpg') center center fixed;
            background-size: cover;
            color: #000; /* Set text color to black */
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh; /* Make the body take up the full height of the viewport */
        }
      
    </style>
</head>

<div class="container">
    <?php include "includes/nav.php"; ?>
    <div class="container col-lg-9 col-md-11 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-1 col-sm-offset-0 col-xs-offset-0 " style="margin-top: 20px">
        <div class="jumbotron login2 col-lg-10 col-md-11 col-sm-12 col-xs-12">
            <p class="page-header" style="text-align: center">ADD EXERCISE</p>
            <div class="container">
                <form class="form-horizontal" role="form" enctype="multipart/form-data" action="addExercise.php" method="post">
                    <!-- Fields for Exercise -->
                    <div class="form-group">
                        <label for="Exercise_ID" class="col-sm-2 control-label">Exercise ID</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Exercise_ID" placeholder="Enter Exercise ID" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Exercise_Name" class="col-sm-2 control-label">Exercise Name</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Exercise_Name" placeholder="Enter Exercise Name" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Exercise_Type" class="col-sm-2 control-label">Exercise Type</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Exercise_Type" placeholder="Enter Exercise Type" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Exercise_Timeslot" class="col-sm-2 control-label">Timeslot</label>
                        <div class="col-sm-10">
                            <input type="time" class="form-control" name="Exercise_Timeslot" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Exercise_Number_Attending" class="col-sm-2 control-label">Number Attending</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Exercise_Number_Attending" placeholder="Enter Number Attending" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <button name="submit" class="btn btn-info col-lg-12" data-toggle="modal" data-target="#info">
                                ADD EXERCISE
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html>