<?php
require 'includes/snippet.php';
require 'includes/db-inc.php';
include "includes/header.php";

if (isset($_POST['submit'])) {
    $Member_ID = sanitize(trim($_POST['Member_ID']));
    $Subscription_ID = sanitize(trim($_POST['Subscription_ID']));
    $Sub_Date = sanitize(trim($_POST['Sub_Date']));

    $sql = "INSERT INTO Subscribes  (Member_ID, Subscription_ID, Sub_Date)
            VALUES('$Member_ID', '$Subscription_ID', '$Sub_Date')";
    $query = mysqli_query($conn, $sql);

    if ($query) {
        echo "<script>alert('New Subscription has been added'); location.href ='subscribes_table.php';</script>";
    } else {
        echo "<script>alert('Subscription not added');</script>";
    }
}
?>
 <!DOCTYPE html>
<html>
<head>
    
    <style>
        body {
            background: url('BG.jpg') center center fixed;
            background-size: cover;
            color: #000; /* Set text color to black */
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh; /* Make the body take up the full height of the viewport */
        }
      
    </style>
</head>

<div class="container">
    <?php include "includes/nav.php"; ?>
    <div class="container col-lg-9 col-md-11 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-1 col-sm-offset-0 col-xs-offset-0 " style="margin-top: 20px">
        <div class="jumbotron login2 col-lg-10 col-md-11 col-sm-12 col-xs-12">
            <p class="page-header" style="text-align: center">ADD SUBSCRIBES</p>
            <div class="container">
                <form class="form-horizontal" role="form" enctype="multipart/form-data" action="addSubscribes.php" method="post">
                    <!-- Fields for Subscription -->
                    <div class="form-group">
                        <label for="Member_ID" class="col-sm-2 control-label">Member ID</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Member_ID" placeholder="Enter Member ID" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Subscription_ID" class="col-sm-2 control-label">Subscription ID</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Subscription_ID" placeholder="Enter Subscription ID" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Sub_Date" class="col-sm-2 control-label">Subscription Date</label>
                        <div class="col-sm-10">
                            <input type="date" class="form-control" name="Sub_Date" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <button name="submit" class="btn btn-info col-lg-12" data-toggle="modal" data-target="#info">
                                ADD SUBSCRIBES
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html>
