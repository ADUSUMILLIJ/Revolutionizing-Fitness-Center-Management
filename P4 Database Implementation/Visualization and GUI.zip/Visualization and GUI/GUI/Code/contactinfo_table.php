<?php
require 'includes/snippet.php';
require 'includes/db-inc.php';
include "includes/header.php";

// Delete record
if (isset($_POST['del'])) {
    $id = sanitize(trim($_POST['Contact_ID']));
    $sql_del = "DELETE FROM contactinfo WHERE Contact_ID = $id";
    $error = false;
    $result = mysqli_query($conn, $sql_del);

    if ($result) {
        $error = true; // Delete successful
    }
}

// Fetch data
$sql_select = "SELECT * FROM contactinfo";
$query = mysqli_query($conn, $sql_select);

?>
 <head>
    <style>
        body {
            background-color: black; /* Set the background color to black */
            color:black; /* Set text color to white */
        }
    </style>
</head>

<div class="container">
    <?php include "includes/nav.php"; ?>
    <div class="alert alert-warning col-lg-7 col-md-12 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-0 col-sm-offset-1 col-xs-offset-0" style="margin-top:70px">
        <span class="glyphicon glyphicon-earphone"></span>
        <strong>Contact Information Table</strong>
    </div>
</div>

<div class="container">
    <div class="panel panel-default">
        <div class="panel-heading">
            <?php if (isset($error) === true) { ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <strong>Record Deleted Successfully!</strong>
                </div>
            <?php } ?>
            <div class="row">
            <a href="admin.php" class="btn btn-primary col-lg-3 col-md-4 col-sm-11 col-xs-11 button" style="margin-left: 15px;margin-bottom: 5px">
                    <span class="glyphicon glyphicon-chevron-left"></span> Back 
                </a>
                <a href="addContact.php">
                    <button class="btn btn-success col-lg-3 col-md-4 col-sm-11 col-xs-11 button" style="margin-left: 15px; margin-bottom: 5px">
                        <span class="glyphicon glyphicon-plus-sign"></span> Add Contact Information
                    </button>
                </a>
            </div>
        </div>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Contact_ID</th>
                    <th>Trainer_ID</th>
                    <th>Member_ID</th>
                    <th>Trainer_Assigned_Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = mysqli_fetch_array($query)) {
                ?>
                    <tr>
                        <td><?php echo $row['Contact_ID']; ?></td>
                        <td><?php echo $row['Trainer_ID']; ?></td>
                        <td><?php echo $row['Member_ID']; ?></td>
                        <td><?php echo $row['Trainer_Assigned_Date']; ?></td>
                        <td>
                            <form method='post' action='contactinfo_table.php'>
                                <input type='hidden' value="<?php echo $row['Contact_ID']; ?>" name='Contact_ID'>
                                <button name='del' type='submit' value='Delete' class='btn btn-warning'>DELETE</button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>

</body>
</html>
