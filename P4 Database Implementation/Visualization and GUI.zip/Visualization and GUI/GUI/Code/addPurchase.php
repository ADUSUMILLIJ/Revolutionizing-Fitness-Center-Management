<?php
require 'includes/snippet.php';
require 'includes/db-inc.php';
include "includes/header.php";

if (isset($_POST['submit'])) {
    $Member_ID = sanitize(trim($_POST['Member_ID']));
    $Merchandise_ID = sanitize(trim($_POST['Merchandise_ID']));
    $Pur_Date = sanitize(trim($_POST['Pur_Date']));

    $sql = "INSERT INTO Purchase (Member_ID, Merchandise_ID, Pur_Date)
            VALUES('$Member_ID', '$Merchandise_ID', '$Pur_Date')";
    $query = mysqli_query($conn, $sql);

    if ($query) {
        echo "<script>alert('New Purchase has been added'); location.href ='purchase_table.php';</script>";
    } else {
        echo "<script>alert('Purchase not added');</script>";
    }
}
?>
 <!DOCTYPE html>
<html>
<head>
    
    <style>
        body {
            background: url('BG.jpg') center center fixed;
            background-size: cover;
            color: #000; /* Set text color to black */
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh; /* Make the body take up the full height of the viewport */
        }
      
    </style>
</head>

<div class="container">
    <?php include "includes/nav.php"; ?>
    <div class="container col-lg-9 col-md-11 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-1 col-sm-offset-0 col-xs-offset-0 " style="margin-top: 20px">
        <div class="jumbotron login2 col-lg-10 col-md-11 col-sm-12 col-xs-12">
            <p class="page-header" style="text-align: center">ADD PURCHASE</p>
            <div class="container">
                <form class="form-horizontal" role="form" enctype="multipart/form-data" action="addPurchase.php" method="post">
                    <!-- Fields for Purchase -->
                    <div class="form-group">
                        <label for="Member_ID" class="col-sm-2 control-label">Member ID</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Member_ID" placeholder="Enter Member ID" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Merchandise_ID" class="col-sm-2 control-label">Merchandise ID</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Merchandise_ID" placeholder="Enter Merchandise ID" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Pur_Date" class="col-sm-2 control-label">Purchase Date</label>
                        <div class="col-sm-10">
                            <input type="date" class="form-control" name="Pur_Date" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <button name="submit" class="btn btn-info col-lg-12" data-toggle="modal" data-target="#info">
                                ADD PURCHASE
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html>
