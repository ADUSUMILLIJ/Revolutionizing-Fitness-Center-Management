<?php
require 'includes/snippet.php';
require 'includes/db-inc.php';
include "includes/header.php";

if (isset($_POST['submit'])) {
    $Exercise_ID = sanitize(trim($_POST['Exercise_ID']));
    $Trainer_ID = sanitize(trim($_POST['Trainer_ID']));
    $Subscription_ID = sanitize(trim($_POST['Subscription_ID']));

    $sql = "INSERT INTO Session (Exercise_ID, Trainer_ID, Subscription_ID)
            VALUES('$Exercise_ID', '$Trainer_ID', '$Subscription_ID')";
    $query = mysqli_query($conn, $sql);

    if ($query) {
        echo "<script>alert('New Session has been added');location.href ='session_table.php';</script>";
    } else {
        echo "<script>alert('Session not added');</script>";
    }
}
?>
 <!DOCTYPE html>
<html>
<head>
    
    <style>
        body {
            background: url('BG.jpg') center center fixed;
            background-size: cover;
            color: #000; /* Set text color to black */
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh; /* Make the body take up the full height of the viewport */
        }
      
    </style>
</head>

<div class="container">
    <?php include "includes/nav.php"; ?>
    <div class="container col-lg-9 col-md-11 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-1 col-sm-offset-0 col-xs-offset-0 " style="margin-top: 20px">
        <div class="jumbotron login2 col-lg-10 col-md-11 col-sm-12 col-xs-12">
            <p class="page-header" style="text-align: center">ADD SESSION</p>
            <div class="container">
                <form class="form-horizontal" role="form" enctype="multipart/form-data" action="addSession.php" method="post">
                    <!-- Fields for Session -->
                    <div class="form-group">
                        <label for="Exercise_ID" class="col-sm-2 control-label">Exercise ID</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Exercise_ID" placeholder="Enter Exercise ID" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Trainer_ID" class="col-sm-2 control-label">Trainer ID</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Trainer_ID" placeholder="Enter Trainer ID" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Subscription_ID" class="col-sm-2 control-label">Subscription ID</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Subscription_ID" placeholder="Enter Subscription ID" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <button name="submit" class="btn btn-info col-lg-12" data-toggle="modal" data-target="#info">
                                ADD SESSION
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html>
