<?php
require 'includes/snippet.php';
require 'includes/db-inc.php';
include "includes/header.php";

if (isset($_POST['submit'])) {
    $Selection_ID = sanitize(trim($_POST['Selection_ID']));
    $Member_ID = sanitize(trim($_POST['Member_ID']));
    $Exercise_ID = sanitize(trim($_POST['Exercise_ID']));
    $Sel_Date = sanitize(trim($_POST['Sel_Date']));

    $sql = "INSERT INTO Selection (Selection_ID, Member_ID, Exercise_ID, Sel_Date)
            VALUES('$Selection_ID', '$Member_ID', '$Exercise_ID', '$Sel_Date')";
    $query = mysqli_query($conn, $sql);

    if ($query) {
        echo "<script>alert('New Selection has been added'); location.href ='selection_table.php';</script>";
    } else {
        echo "<script>alert('Selection not added');</script>";
    }
}
?>
 <!DOCTYPE html>
<html>
<head>
    
    <style>
        body {
            background: url('BG.jpg') center center fixed;
            background-size: cover;
            color: #000; /* Set text color to black */
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh; /* Make the body take up the full height of the viewport */
        }
      
    </style>
</head>

<div class="container">
    <?php include "includes/nav.php"; ?>
    <div class="container col-lg-9 col-md-11 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-1 col-sm-offset-0 col-xs-offset-0 " style="margin-top: 20px">
        <div class="jumbotron login2 col-lg-10 col-md-11 col-sm-12 col-xs-12">
            <p class="page-header" style="text-align: center">ADD SELECTION</p>
            <div class="container">
                <form class="form-horizontal" role="form" enctype="multipart/form-data" action="addSelection.php" method="post">
                    <!-- Fields for Selection -->
                    <div class="form-group">
                        <label for="Selection_ID" class="col-sm-2 control-label">Selection ID</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Selection_ID" placeholder="Enter Selection ID" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Member_ID" class="col-sm-2 control-label">Member ID</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Member_ID" placeholder="Enter Member ID" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Exercise_ID" class="col-sm-2 control-label">Exercise ID</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Exercise_ID" placeholder="Enter Exercise ID" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Sel_Date" class="col-sm-2 control-label">Selection Date</label>
                        <div class="col-sm-10">
                            <input type="date" class="form-control" name="Sel_Date" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <button name="submit" class="btn btn-info col-lg-12" data-toggle="modal" data-target="#info">
                                ADD SELECTION
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html>
