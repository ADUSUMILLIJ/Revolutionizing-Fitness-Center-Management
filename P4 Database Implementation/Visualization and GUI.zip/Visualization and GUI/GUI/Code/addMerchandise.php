<?php
require 'includes/snippet.php';
require 'includes/db-inc.php';
include "includes/header.php";

if (isset($_POST['submit'])) {
    $Merchandise_ID = sanitize(trim($_POST['Merchandise_ID']));
    $Merch_Color = sanitize(trim($_POST['Merch_Color']));
    $Merch_Price = sanitize(trim($_POST['Merch_Price']));
    $Merch_Size = sanitize(trim($_POST['Merch_Size']));
    $Merch_Style = sanitize(trim($_POST['Merch_Style']));
    $Merch_Sold = sanitize(trim($_POST['Merch_Sold']));
    $Merch_Instock = sanitize(trim($_POST['Merch_Instock']));

    $sql = "INSERT INTO Merchandise (Merchandise_ID, Merch_Color, Merch_Price, Merch_Size, Merch_Style, Merch_Sold, Merch_Instock)
            VALUES('$Merchandise_ID', '$Merch_Color', '$Merch_Price', '$Merch_Size', '$Merch_Style', '$Merch_Sold', '$Merch_Instock')";
    $query = mysqli_query($conn, $sql);

    if ($query) {
        echo "<script>alert('New Merchandise has been added'); location.href ='merchandise_table.php';</script>";
    } else {
        echo "<script>alert('Merchandise not added');</script>";
    }
}
?>
 <!DOCTYPE html>
<html>
<head>
    
    <style>
        body {
            background: url('BG.jpg') center center fixed;
            background-size: cover;
            color: #000; /* Set text color to black */
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh; /* Make the body take up the full height of the viewport */
        }
      
    </style>
</head>

<div class="container">
    <?php include "includes/nav.php"; ?>
    <div class="container col-lg-9 col-md-11 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-1 col-sm-offset-0 col-xs-offset-0 " style="margin-top: 20px">
        <div class="jumbotron login2 col-lg-10 col-md-11 col-sm-12 col-xs-12">
            <p class="page-header" style="text-align: center">ADD MERCHANDISE</p>
            <div class="container">
                <form class="form-horizontal" role="form" enctype="multipart/form-data" action="addMerchandise.php" method="post">
                    <!-- Fields for Merchandise -->
                    <div class="form-group">
                        <label for="Merchandise_ID" class="col-sm-2 control-label">Merchandise ID</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Merchandise_ID" placeholder="Enter Merchandise Id" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Merch_Color" class="col-sm-2 control-label">Color</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Merch_Color" placeholder="Enter Color" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Merch_Price" class="col-sm-2 control-label">Price</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Merch_Price" placeholder="Enter Price" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Merch_Size" class="col-sm-2 control-label">Size</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Merch_Size" placeholder="Enter Size" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Merch_Style" class="col-sm-2 control-label">Style</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Merch_Style" placeholder="Enter Style" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Merch_Sold" class="col-sm-2 control-label">Sold</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Merch_Sold" placeholder="Enter Sold quantity" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Merch_Instock" class="col-sm-2 control-label">In Stock</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Merch_Instock" placeholder="Enter In Stock quantity" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <button name="submit" class="btn btn-info col-lg-12" data-toggle="modal" data-target="#info">
                                ADD MERCHANDISE
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>

</body>

</html>
