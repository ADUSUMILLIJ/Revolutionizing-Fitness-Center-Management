<?php
require 'includes/snippet.php';
require 'includes/db-inc.php';
include "includes/header.php";

if (isset($_POST['submit'])) {
    $Trainer_ID = sanitize(trim($_POST['Trainer_ID']));
    $Trainer_Name = sanitize(trim($_POST['Trainer_Name']));
    $Trainer_Email = sanitize(trim($_POST['Trainer_Email']));
    $Trainer_Gender = sanitize(trim($_POST['Trainer_Gender']));
    $Trainer_StartDate = sanitize(trim($_POST['Trainer_StartDate']));
    $Trainer_Experience = sanitize(trim($_POST['Trainer_Experience']));
    $Trainer_Salary = sanitize(trim($_POST['Trainer_Salary']));
    $Trainer_Contact = sanitize(trim($_POST['Trainer_Contact']));

    $sql = "INSERT INTO Trainer(Trainer_ID, Trainer_Name, Trainer_Email, Trainer_Gender, Trainer_StartDate, Trainer_Experience, Trainer_Salary, Trainer_Contact)
            VALUES('$Trainer_ID', '$Trainer_Name', '$Trainer_Email', '$Trainer_Gender', '$Trainer_StartDate', '$Trainer_Experience', '$Trainer_Salary', '$Trainer_Contact')";
    $query = mysqli_query($conn, $sql);

    if ($query) {
        echo "<script>alert('New Trainer has been added');location.href ='trainer_table.php';</script>";
    } else {
        echo "<script>alert('Trainer not added');</script>";
    }
}
?>
 <!DOCTYPE html>
<html>
<head>
    
    <style>
        body {
            background: url('BG.jpg') center center fixed;
            background-size: cover;
            color: #000; /* Set text color to black */
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh; /* Make the body take up the full height of the viewport */
        }
      
    </style>
</head>

<div class="container">
    <?php include "includes/nav.php"; ?>
    <div class="container col-lg-9 col-md-11 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-1 col-sm-offset-0 col-xs-offset-0 " style="margin-top: 20px">
        <div class="jumbotron login2 col-lg-10 col-md-11 col-sm-12 col-xs-12">
            <p class="page-header" style="text-align: center">ADD TRAINER</p>
            <div class="container">
                <form class="form-horizontal" role="form" enctype="multipart/form-data" action="addTrainers.php" method="post">
                    <!-- Fields for Trainer -->
                    <div class="form-group">
                        <label for="Trainer_ID" class="col-sm-2 control-label">Trainer ID</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Trainer_ID" placeholder="Enter Trainer Id" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Trainer_Name" class="col-sm-2 control-label">Trainer Name</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Trainer_Name" placeholder="Enter Trainer Name" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Trainer_Email" class="col-sm-2 control-label">Trainer Email</label>
                        <div class="col-sm-10">
                            <input type="email" class="form-control" name="Trainer_Email" placeholder="Enter Trainer Email" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Trainer_Gender" class="col-sm-2 control-label">Trainer Gender</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Trainer_Gender" placeholder="Enter Trainer Gender" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Trainer_StartDate" class="col-sm-2 control-label">Trainer StartDate</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Trainer_StartDate" placeholder="Enter Trainer StartDate" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Trainer_Experience" class="col-sm-2 control-label">Trainer Experience</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Trainer_Experience" placeholder="Enter Trainer Experience" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Trainer_Salary" class="col-sm-2 control-label">Trainer Salary</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Trainer_Salary" placeholder="Enter Trainer Salary" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Trainer_Contact" class="col-sm-2 control-label">Trainer Contact</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Trainer_Contact" placeholder="Enter Trainer Contact" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <button name="submit" class="btn btn-info col-lg-12" data-toggle="modal" data-target="#info">
                                ADD TRAINER
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>

</body>

</html>
