<?php
   session_start(); 
   // session_destroy();
   if (!(isset($_SESSION['auth']) && $_SESSION['auth'] === true)) {
   	header("Location: index.php");
   	exit();
   }
   else {
    	$admin = $_SESSION['admin'];
   }
   require 'includes/db-inc.php';
   include "includes/header.php";
   
   ?>
 <!DOCTYPE html>
<html>
<head>
    <title>Admin Home</title>
    <style>
        body {
            background: url('Wall.jpg') center center fixed;
            background-size: cover;
            color: #000; /* Set text color to black */
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh; /* Make the body take up the full height of the viewport */
        }
        .container {
            background-color: rgba(455, 455, 455, 0.8); /* Adjust the background color and opacity of the container */
            padding: 1px;
            border-radius: 1px;
            color:Black;
        }
        h1 {
            font-family:Sans-serif;
            font-weight:1000;
            text-align: center; 
            background-color: transparent; /* Set background color to transparent */
            margin:100; 
        }
    </style>
</head>
<body>
    <div class="container">
        <?php include "includes/nav.php"; ?>
        <div class="row">
            <h1>Welcome</h1>
        </div>
    </div>
    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html>































