<?php 
   require 'includes/snippet.php';
   require 'includes/db-inc.php';
   include "includes/header.php";    
   
   if(isset($_POST['del'])){
   
   	$id = sanitize(trim($_POST['Member_ID']));
   
   	$sql_del = "DELETE from members where Member_ID = $id"; 
   	$error = false;
   	$result = mysqli_query($conn,$sql_del);
   			if ($result)
   			{
   			$error = true; //delete successful
   			}			
   
    }
   ?>
<head>
    <style>
        body {
            background-color: black; /* Set the background color to black */
            color:black; /* Set text color to white */
        }
    </style>
</head>

<div class="container">
   <?php include "includes/nav.php"; ?>
   <!-- navbar ends -->
   <!-- info alert -->
   <div class="alert alert-warning col-lg-7 col-md-12 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-0 col-sm-offset-1 col-xs-offset-0" style="top:10px">
      <span class="glyphicon glyphicon-book"></span>
      <strong>MembersTable</strong> Table
   </div>
</div>
<div class="container">
   <div class="panel panel-default">
      <!-- Default panel contents -->
      <div class="panel-heading">
         <?php if(isset($error)===true) { ?>
         <div class="alert alert-success alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <strong>Record Deleted Successfully!</strong>
         </div>
         <?php } ?>
         <div class="row">
         <a href="admin.php" class="btn btn-primary col-lg-3 col-md-4 col-sm-11 col-xs-11 button" style="margin-left: 15px;margin-bottom: 5px">
                    <span class="glyphicon glyphicon-chevron-left"></span> Back 
                </a>
            <a href="addMembers.php"><button class="btn btn-success col-lg-3 col-md-4 col-sm-11 col-xs-11 button" style="margin-left: 15px;margin-bottom: 5px"><span class="glyphicon glyphicon-plus-sign"></span> Add Member</button></a>
         </div>
      </div>
      <div class="table-responsive">
      <table class="table table-bordered">
      


         <thead>
            <tr>
               <th style="width: 10%;">  Member_ID</th>
               <th style="width: 10%;">  Member_name </th>
               <th style="width: 10%;">  Member_Startdate </th>
               <th style="width: 10%;">  Member_Gender </th>
               <th style="width: 10%;">  Member_Contact</th> 
               <th style="width: 10%;">  Member_weight</th> 
               <th style="width: 10%;">  Member_height </th>
               <th style="width: 10%;">  Member_birthday </th>
               <th style="width: 10%;">  Member_emailid </th>
               <th style="width: 10%;"> Action</th>
                <!-- Added a new column for the delete button -->
            </tr>
         </thead>
         <tbody>
            <?php 
               $sql = "SELECT * from members";
               
               $query = mysqli_query($conn, $sql); 
               $counter = 1;
               while ($row = mysqli_fetch_array($query)) { ?>
            <tr>
               <td style="padding:0.0001px;"><?php echo $row['Member_ID']; ?></td>
               <td  style="padding: 0.0001px;"><?php echo $row['Member_name']; ?></td>
               <td  style="padding: 0.0001px;"><?php echo $row['Member_Startdate']; ?></td>
               <td  style="padding: 0.0001px;"><?php echo $row['Member_Gender']; ?></td>
               <td  style="padding: 0.0001px;"><?php echo $row['Member_Contact']; ?></td>
               <td  style="padding: 0.0001px;"><?php echo $row['Member_weight']; ?></td>
               <td  style="padding: 0.0001px;"><?php echo $row['Member_height']; ?></td>
               <td  style="padding: 0.0001px;"><?php echo $row['Member_birthday']; ?></td>
               <td  style="padding: 0.0001px;"><?php echo $row['Member_emailid']; ?></td>
               <td>
                  <form method='post' action='MembersTable.php'>
                     <input type='hidden' value="<?php echo $row['Member_ID']; ?>" name='Member_ID'>
                     <button name='del' type='submit' value='Delete' class='btn btn-warning'>DELETE</button>
                  </form>
               </td>
            </tr>
            <?php 	}
               ?>
         </tbody>
      </table>
   </div>
               </div>
</div>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>	
</body>
</html>