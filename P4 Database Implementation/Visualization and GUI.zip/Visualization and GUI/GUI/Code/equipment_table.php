<?php
require 'includes/snippet.php';
require 'includes/db-inc.php';
include "includes/header.php";

if (isset($_POST['del'])) {
    $id = sanitize(trim($_POST['Equip_ID']));

    $sql_del = "DELETE FROM  Equipment WHERE Equip_ID = $id";
    $error = false;
    $result = mysqli_query($conn, $sql_del);

    if ($result) {
        $error = true; // Delete successful
    }
}
?>
<head>
    <style>
        body {
            background-color: black; /* Set the background color to black */
            color:black; /* Set text color to white */
        }
    </style>
</head>

<div class="container">
    <?php include "includes/nav.php"; ?>
    <div class="alert alert-warning col-lg-7 col-md-12 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-0 col-sm-offset-1 col-xs-offset-0" style="margin-top:70px">
        <span class="glyphicon glyphicon-calendar"></span>
        <strong>Your Equipment Table</strong>
    </div>
</div>

<div class="container">
    <div class="panel panel-default">
        <div class="panel-heading">
            <?php if (isset($error) === true) { ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <strong>Record Deleted Successfully!</strong>
                </div>
            <?php } ?>
            <div class="row">
            <a href="admin.php" class="btn btn-primary col-lg-3 col-md-4 col-sm-11 col-xs-11 button" style="margin-left: 15px;margin-bottom: 5px">
                    <span class="glyphicon glyphicon-chevron-left"></span> Back 
                </a>
                <a href="addEquipment.php">
                    <button class="btn btn-success col-lg-3 col-md-4 col-sm-11 col-xs-11 button" style="margin-left: 15px; margin-bottom: 5px">
                        <span class="glyphicon glyphicon-plus-sign"></span> Add Equipment
                    </button>
                </a>
            </div>
        </div>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Equip_ID</th>
                    <th>Equip_Quantity</th>
                    <th>Equip_Cost</th>
                    <th>Equip_Name</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM Equipment";
                $query = mysqli_query($conn, $sql);
                if (!$query) {
                    die('Error in SQL query: ' . mysqli_error($conn));
                }
                
                $counter = 1;

                while ($row = mysqli_fetch_array($query)) {
                ?>
                    <tr>
                        <td><?php echo $row['Equip_ID']; ?></td>
                        <td><?php echo $row['Equip_Quantity']; ?></td>
                        <td><?php echo $row['Equip_Cost']; ?></td>
                        <td><?php echo $row['Equip_Name']; ?></td>
                        <td>
                            <form method='post' action='equipment_table.php'>
                                <input type='hidden' value="<?php echo $row['Equip_ID']; ?>" name='Equip_ID'>
                                <button name='del' type='submit' value='Delete' class='btn btn-warning'>DELETE</button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>

</body>
</html>
