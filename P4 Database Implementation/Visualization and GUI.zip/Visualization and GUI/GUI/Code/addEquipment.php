If you want to modify your PHP code to handle the insertion of data into a table named `Equipment` with the provided structure, you can follow the same pattern as before. Here's the modified code for adding new equipment:

```php
<?php
require 'includes/snippet.php';
require 'includes/db-inc.php';
include "includes/header.php";

if (isset($_POST['submit'])) {
    $Equip_Quantity = sanitize(trim($_POST['Equip_Quantity']));
    $Equip_Cost = sanitize(trim($_POST['Equip_Cost']));
    $Equip_Name = sanitize(trim($_POST['Equip_Name']));

    $sql = "INSERT INTO Equipment (Equip_Quantity, Equip_Cost, Equip_Name)
            VALUES('$Equip_Quantity', '$Equip_Cost', '$Equip_Name')";
    $query = mysqli_query($conn, $sql);

    if ($query) {
        echo "<script>alert('New Equipment has been added');location.href ='equipment_table.php';</script>";
    } else {
        echo "<script>alert('Equipment not added');</script>";
    }
}
?>
 <!DOCTYPE html>
<html>
<head>
    
    <style>
        body {
            background: url('BG.jpg') center center fixed;
            background-size: cover;
            color: #000; /* Set text color to black */
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh; /* Make the body take up the full height of the viewport */
        }
      
    </style>
</head>


<div class="container">
    <?php include "includes/nav.php"; ?>
    <div class="container col-lg-9 col-md-11 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-1 col-sm-offset-0 col-xs-offset-0 " style="margin-top: 20px">
        <div class="jumbotron login2 col-lg-10 col-md-11 col-sm-12 col-xs-12">
            <p class="page-header" style="text-align: center">ADD EQUIPMENT</p>
            <div class="container">
                <form class="form-horizontal" role="form" enctype="multipart/form-data" action="addEquipment.php" method="post">
                    <!-- Fields for Equipment -->
                    <div class="form-group">
                        <label for="Equip_Quantity" class="col-sm-2 control-label">Quantity</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Equip_Quantity" placeholder="Enter Quantity" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Equip_Cost" class="col-sm-2 control-label">Cost</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Equip_Cost" placeholder="Enter Cost" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Equip_Name" class="col-sm-2 control-label">Name</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Equip_Name" placeholder="Enter Name" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <button name="submit" class="btn btn-info col-lg-12" data-toggle="modal" data-target="#info">
                                ADD EQUIPMENT
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html>
```
