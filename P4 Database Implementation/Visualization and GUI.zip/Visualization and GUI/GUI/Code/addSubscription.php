<?php
require 'includes/snippet.php';
require 'includes/db-inc.php';
include "includes/header.php";

if (isset($_POST['submit'])) {
    $Sub_StartDate = sanitize(trim($_POST['Sub_StartDate']));
    $Sub_DurationDays = sanitize(trim($_POST['Sub_DurationDays']));
    $Sub_Plan = sanitize(trim($_POST['Sub_Plan']));
    $Sub_Renewal = sanitize(trim($_POST['Sub_Renewal']));
    $Sub_AccountDetails = sanitize(trim($_POST['Sub_AccountDetails']));
    $Sub_Cancellation = sanitize(trim($_POST['Sub_Cancellation']));
    $No_of_Sub = sanitize(trim($_POST['No_of_Sub']));

    $sql = "INSERT INTO Subscription (Sub_StartDate, Sub_DurationDays, Sub_Plan, Sub_Renewal, Sub_AccountDetails, Sub_Cancellation, No_of_Sub)
            VALUES('$Sub_StartDate', '$Sub_DurationDays', '$Sub_Plan', '$Sub_Renewal', '$Sub_AccountDetails', '$Sub_Cancellation', '$No_of_Sub')";
    $query = mysqli_query($conn, $sql);

    if ($query) {
        echo "<script>alert('New Subscription has been added'); setTimeout(function(){ window.close(); }, 2000);</script>";
    } else {
        echo "<script>alert('Subscription not added');</script>";
    }
}
?>
 <!DOCTYPE html>
<html>
<head>
    
    <style>
        body {
            background: url('BG.jpg') center center fixed;
            background-size: cover;
            color: #000; /* Set text color to black */
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh; /* Make the body take up the full height of the viewport */
        }
      
    </style>
</head>

<div class="container">
    <?php include "includes/nav.php"; ?>
    <div class="container col-lg-9 col-md-11 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-1 col-sm-offset-0 col-xs-offset-0 " style="margin-top: 20px">
        <div class="jumbotron login2 col-lg-10 col-md-11 col-sm-12 col-xs-12">
            <p class="page-header" style="text-align: center">ADD SUBSCRIPTION</p>
            <div class="container">
                <form class="form-horizontal" role="form" enctype="multipart/form-data" action="addSubscription.php" method="post">
                    <!-- Fields for Subscription -->
                    <div class="form-group">
                        <label for="Sub_StartDate" class="col-sm-2 control-label">Start Date</label>
                        <div class="col-sm-10">
                            <input type="date" class="form-control" name="Sub_StartDate" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Sub_DurationDays" class="col-sm-2 control-label">Duration (Days)</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Sub_DurationDays" placeholder="Enter Duration in Days" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Sub_Plan" class="col-sm-2 control-label">Plan</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Sub_Plan" placeholder="Enter Plan" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Sub_Renewal" class="col-sm-2 control-label">Renewal Date</label>
                        <div class="col-sm-10">
                            <input type="date" class="form-control" name="Sub_Renewal">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Sub_AccountDetails" class="col-sm-2 control-label">Account Details</label>
                        <div class="col-sm-10">
                            <textarea class="form-control" name="Sub_AccountDetails" rows="3" placeholder="Enter Account Details" required></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Sub_Cancellation" class="col-sm-2 control-label">Cancellation Date</label>
                        <div class="col-sm-10">
                            <input type="date" class="form-control" name="Sub_Cancellation">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="No_of_Sub" class="col-sm-2 control-label">Number of Subscriptions</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="No_of_Sub" placeholder="Enter Number of Subscriptions" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <button name="submit" class="btn btn-info col-lg-12" data-toggle="modal" data-target="#info">
                                ADD SUBSCRIPTION
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html>
