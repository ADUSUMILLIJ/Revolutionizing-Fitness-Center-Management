<nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
         <!--   <a class="navbar-brand" href="admin.php">Gym Management System</a>-->
        </div>

        <div class="collapse navbar-collapse" id="bs-example">
            <ul class="nav navbar-nav">
                <?php if (isset($admin)) { ?>
                    <li class="active"><a href="admin.php">Home</a></li>
                 
                    <!-- Add a dropdown menu item -->
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Manage Tables <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="users.php">Users</a></li>
                            <li><a href="MembersTable.php">Members</a></li>
                            <li><a href="exercises_table.php">Exercise</a></li>
                            <li><a href="merchandise_table.php">Merchandise</a></li>
                            <li><a href="trainer_table.php">Trainer</a></li>
                            <li><a href="selection_table.php">Selection</a></li>
                            <li><a href="session_table.php">Session</a></li>
                            <li><a href="purchase_table.php">Purchase</a></li>
                            <li><a href="equipment_table.php">Equipment</a></li>
                            <li><a href="subscription_table.php">Subscription</a></li>
                            <li><a href="subscribes_table.php">Subscribes</a></li>
                            <li><a href="performs_table.php">Performs</a></li>
                            <li><a href="usages_table.php">usages</a></li>
                            <li><a href="contactinfo_table.php">ContactInfo</a></li>
                        </ul>
                    </li>
                <?php } ?>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>
