<?php
require 'includes/snippet.php';
require 'includes/db-inc.php';
include "includes/header.php";

if (isset($_POST['del'])) {
    $id = sanitize(trim($_POST['Exercise_ID']));

    $sql_del = "DELETE FROM exercise WHERE Exercise_ID = $id";
    $error = false;
    $result = mysqli_query($conn, $sql_del);

    if ($result) {
        $error = true; // Delete successful
    }
}
?>
<head>
    <style>
        body {
            background-color: black; /* Set the background color to black */
            color:black; /* Set text color to white */
        }
    </style>
</head>

<div class="container">
    <?php include "includes/nav.php"; ?>
    <div class="alert alert-warning col-lg-7 col-md-12 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-0 col-sm-offset-1 col-xs-offset-0" style="margin-top:70px">
        <span class="glyphicon glyphicon-book"></span>
        <strong>Exercise Table</strong>
    </div>
</div>

<div class="container">
    <div class="panel panel-default">
        <div class="panel-heading">
            <?php if (isset($error) === true) { ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <strong>Record Deleted Successfully!</strong>
                </div>
            <?php } ?>
            <div class="row">
            <a href="admin.php" class="btn btn-primary col-lg-3 col-md-4 col-sm-11 col-xs-11 button" style="margin-left: 15px;margin-bottom: 5px">
                    <span class="glyphicon glyphicon-chevron-left"></span> Back 
                </a>
                <a href="addExercise.php">
                    <button class="btn btn-success col-lg-3 col-md-4 col-sm-11 col-xs-11 button" style="margin-left: 15px; margin-bottom: 5px">
                        <span class="glyphicon glyphicon-plus-sign"></span> Add Exercise
                    </button>
                </a>
            </div>
        </div>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Exercise_ID</th>
                    <th>Exercise_Name</th>
                    <th>Exercise_Type</th>
                    <th>Exercise_Timeslot</th>
                    <th>Exercise_Number_Attending</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM exercise";
                $query = mysqli_query($conn, $sql);
                $counter = 1;

                while ($row = mysqli_fetch_array($query)) {
                ?>
                    <tr>
                        <td><?php echo $row['Exercise_ID']; ?></td>
                        <td><?php echo $row['Exercise_Name']; ?></td>
                        <td><?php echo $row['Exercise_Type']; ?></td>
                        <td><?php echo $row['Exercise_Timeslot']; ?></td>
                        <td><?php echo $row['Exercise_Number_Attending']; ?></td>
                        <td>
                            <form method='post' action='exercises_table.php'>
                                <input type='hidden' value="<?php echo $row['Exercise_ID']; ?>" name='Exercise_ID'>
                                <button name='del' type='submit' value='Delete' class='btn btn-warning'>DELETE</button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>

</body>
</html>
```
