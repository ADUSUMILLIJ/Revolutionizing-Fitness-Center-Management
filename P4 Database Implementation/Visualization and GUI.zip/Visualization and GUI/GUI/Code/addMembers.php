<?php
require 'includes/snippet.php';
require 'includes/db-inc.php';
include "includes/header.php";

if (isset($_POST['submit'])) {
    $Member_ID = sanitize(trim($_POST['Member_ID']));
    $Member_name = sanitize(trim($_POST['Member_name']));
    $Member_Startdate = sanitize(trim($_POST['Member_Startdate']));
    $Member_Gender = sanitize(trim($_POST['Member_Gender']));
    $Member_Contact = sanitize(trim($_POST['Member_Contact']));
    $Member_weight = sanitize(trim($_POST['Member_weight']));
    $Member_height = sanitize(trim($_POST['Member_height']));
    $Member_birthday = sanitize(trim($_POST['Member_birthday']));
    $Member_emailid = sanitize(trim($_POST['Member_emailid']));

    $sql = "INSERT INTO Members (Member_ID, Member_name, Member_Startdate, Member_Gender, Member_Contact, Member_weight, Member_height, Member_birthday, Member_emailid)
            VALUES('$Member_ID', '$Member_name', '$Member_Startdate', '$Member_Gender', '$Member_Contact', $Member_weight, $Member_height, '$Member_birthday', '$Member_emailid')";
    $query = mysqli_query($conn, $sql);

    if ($query) {
        echo "<script>alert('New Member has been added '); location.href ='MembersTable.php';</script>";
    } else {
        echo "<script>alert('Member not added!');</script>";
    }
}
?>
 <!DOCTYPE html>
<html>
<head>
    
    <style>
        body {
            background: url('BG.jpg') center center fixed;
            background-size: cover;
            color: #000; /* Set text color to black */
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh; /* Make the body take up the full height of the viewport */
        }
      
    </style>
</head>

<div class="container">
    <?php include "includes/nav.php"; ?>
    <div class="container col-lg-9 col-md-11 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-1 col-sm-offset-0 col-xs-offset-0 " style="margin-top: 20px">
        <div class="jumbotron login2 col-lg-10 col-md-11 col-sm-12 col-xs-12">
            <p class="page-header" style="text-align: center">ADD MEMBER</p>
            <div class="container">
                <form class="form-horizontal" role="form" enctype="multipart/form-data" action="addMembers.php" method="post">
                    <div class="form-group">
                        <label for="Member ID" class="col-sm-2 control-label">Member ID</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Member_ID" placeholder="Enter Member Id" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Member Name" class="col-sm-2 control-label">Member Name</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Member_name" placeholder="Enter Member Name" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Member_Startdate" class="col-sm-2 control-label">Member Startdate</label>
                        <div class="col-sm-10">
                            <input type="date" class="form-control" name="Member_Startdate" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Member Gender" class="col-sm-2 control-label">Member Gender</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Member_Gender" placeholder="Enter Gender" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Member Contact" class="col-sm-2 control-label">Member Contact</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="Member_Contact" placeholder="Enter Contact" required>
                        </div>
                    </div>
                    <!-- New fields added -->
                    <div class="form-group">
                        <label for="Member Weight" class="col-sm-2 control-label">Member Weight</label>
                        <div class="col-sm-10">
                            <input type="number" class="form-control" name="Member_weight" placeholder="Enter Weight" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Member Height" class="col-sm-2 control-label">Member Height</label>
                        <div class="col-sm-10">
                            <input type="number" class="form-control" name="Member_height" placeholder="Enter Height" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Member Birthday" class="col-sm-2 control-label">Member Birthday</label>
                        <div class="col-sm-10">
                            <input type="date" class="form-control" name="Member_birthday" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="Member Email" class="col-sm-2 control-label">Member Email</label>
                        <div class="col-sm-10">
                            <input type="email" class="form-control" name="Member_emailid" placeholder="Enter Email" style="width: 80%;" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <button name="submit" class="btn btn-info col-lg-12" data-toggle="modal" data-target="#info">
                                ADD MEMBER
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>

</body>
</html>
